import { Mail, Phone, MapPin } from "lucide-react";

export default function Contact() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Contact Us</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Have questions or need assistance? We're here to help! Get in touch
            with our team.
          </p>
        </div>

        {/* Contact Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
            <div className="flex justify-center mb-4">
              <Mail className="w-12 h-12 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Email</h3>
            <p className="text-gray-600">support@smartrent.com</p>
            <p className="text-gray-600">info@smartrent.com</p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
            <div className="flex justify-center mb-4">
              <Phone className="w-12 h-12 text-pink-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Phone</h3>
            <p className="text-gray-600">+91 (800) 123-4567</p>
            <p className="text-gray-600">+91 (800) 987-6543</p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
            <div className="flex justify-center mb-4">
              <MapPin className="w-12 h-12 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Address</h3>
            <p className="text-gray-600">SmartRent HQ</p>
            <p className="text-gray-600">Mumbai, India</p>
          </div>
        </div>

        {/* Message Section */}
        <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">
            Prefer to Share Feedback?
          </h2>
          <p className="text-gray-600 mb-8 max-w-xl mx-auto">
            Visit our About Us page to share feedback, request custom
            predictions, or suggest house listings.
          </p>
          <a
            href="/about"
            className="inline-block bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-lg font-bold hover:shadow-lg transition-all duration-300"
          >
            Go to About Us
          </a>
        </div>

        {/* Business Hours */}
        <div className="mt-16 bg-gradient-to-r from-purple-100 to-pink-100 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">
            Business Hours
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="font-semibold text-gray-800">Monday - Friday</p>
              <p className="text-gray-600">9:00 AM - 6:00 PM IST</p>
            </div>
            <div>
              <p className="font-semibold text-gray-800">Saturday - Sunday</p>
              <p className="text-gray-600">10:00 AM - 4:00 PM IST</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
