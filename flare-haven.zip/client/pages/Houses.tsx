import { useParams } from "react-router-dom";
import { MapPin, Home, DollarSign } from "lucide-react";
import { useState } from "react";
import PropertyDetailModal from "@/components/PropertyDetailModal";

interface House {
  id: number;
  name: string;
  price: number;
  city: string;
  bhk: string;
  size: string;
  image: string;
  imageUrl?: string;
  furnishing: string;
}

const sampleHouses: Record<string, House[]> = {
  apartment: [
    {
      id: 1,
      name: "Modern Apartment in Downtown",
      price: 45000,
      city: "Mumbai",
      bhk: "2 BHK",
      size: "1200 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 2,
      name: "Cozy Apartment with City View",
      price: 38000,
      city: "Delhi",
      bhk: "2 BHK",
      size: "1000 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 3,
      name: "Luxury Apartment",
      price: 65000,
      city: "Bangalore",
      bhk: "3 BHK",
      size: "1500 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 4,
      name: "Budget-Friendly Apartment",
      price: 25000,
      city: "Pune",
      bhk: "1 BHK",
      size: "600 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 5,
      name: "Spacious Family Apartment",
      price: 55000,
      city: "Hyderabad",
      bhk: "3 BHK",
      size: "1400 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 6,
      name: "Premium City Center Apartment",
      price: 72000,
      city: "Mumbai",
      bhk: "3 BHK",
      size: "1600 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 7,
      name: "Affordable Apartment",
      price: 32000,
      city: "Kolkata",
      bhk: "2 BHK",
      size: "950 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 8,
      name: "Well-Equipped Apartment",
      price: 42000,
      city: "Chennai",
      bhk: "2 BHK",
      size: "1100 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 9,
      name: "Modern Studio Apartment",
      price: 28000,
      city: "Bangalore",
      bhk: "1 BHK",
      size: "700 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 10,
      name: "Executive Apartment",
      price: 68000,
      city: "Delhi",
      bhk: "3 BHK",
      size: "1550 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 11,
      name: "Contemporary Apartment",
      price: 48000,
      city: "Ahmedabad",
      bhk: "2 BHK",
      size: "1250 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 12,
      name: "Compact Apartment",
      price: 22000,
      city: "Pune",
      bhk: "1 BHK",
      size: "550 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 13,
      name: "Smart Apartment",
      price: 52000,
      city: "Bangalore",
      bhk: "2 BHK",
      size: "1300 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 14,
      name: "Vibrant Apartment",
      price: 36000,
      city: "Mumbai",
      bhk: "2 BHK",
      size: "1050 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 15,
      name: "Elegant Apartment",
      price: 58000,
      city: "Hyderabad",
      bhk: "3 BHK",
      size: "1480 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 16,
      name: "Urban Apartment",
      price: 44000,
      city: "Chennai",
      bhk: "2 BHK",
      size: "1150 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 17,
      name: "Sophisticated Apartment",
      price: 70000,
      city: "Delhi",
      bhk: "3 BHK",
      size: "1700 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 18,
      name: "Cozy Studio Apartment",
      price: 26000,
      city: "Kolkata",
      bhk: "1 BHK",
      size: "680 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 19,
      name: "Spacious Apartment",
      price: 50000,
      city: "Pune",
      bhk: "2 BHK",
      size: "1350 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 20,
      name: "Premium Apartment",
      price: 75000,
      city: "Mumbai",
      bhk: "3 BHK",
      size: "1650 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Furnished",
    },
  ],
  independent: [
    {
      id: 1,
      name: "Modern Independent House",
      price: 85000,
      city: "Delhi",
      bhk: "3 BHK",
      size: "2000 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 2,
      name: "Spacious Independent House",
      price: 75000,
      city: "Bangalore",
      bhk: "2 BHK",
      size: "1800 sq ft",
      image: "��",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 3,
      name: "Luxury Independent House",
      price: 120000,
      city: "Mumbai",
      bhk: "4 BHK",
      size: "2500 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 4,
      name: "Family Independent House",
      price: 65000,
      city: "Pune",
      bhk: "2 BHK",
      size: "1600 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 5,
      name: "Contemporary Independent House",
      price: 95000,
      city: "Hyderabad",
      bhk: "3 BHK",
      size: "2100 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 6,
      name: "Grand Independent House",
      price: 110000,
      city: "Delhi",
      bhk: "4 BHK",
      size: "2400 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 7,
      name: "Affordable Independent House",
      price: 55000,
      city: "Kolkata",
      bhk: "2 BHK",
      size: "1400 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 8,
      name: "Elegant Independent House",
      price: 88000,
      city: "Chennai",
      bhk: "3 BHK",
      size: "1950 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 9,
      name: "Well-Built Independent House",
      price: 78000,
      city: "Bangalore",
      bhk: "3 BHK",
      size: "1850 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 10,
      name: "Executive Independent House",
      price: 105000,
      city: "Mumbai",
      bhk: "4 BHK",
      size: "2300 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 11,
      name: "Modern Independent House",
      price: 82000,
      city: "Ahmedabad",
      bhk: "3 BHK",
      size: "1900 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 12,
      name: "Cozy Independent House",
      price: 52000,
      city: "Pune",
      bhk: "2 BHK",
      size: "1500 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 13,
      name: "Stylish Independent House",
      price: 92000,
      city: "Bangalore",
      bhk: "3 BHK",
      size: "2050 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 14,
      name: "Charming Independent House",
      price: 72000,
      city: "Delhi",
      bhk: "2 BHK",
      size: "1700 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 15,
      name: "Luxurious Independent House",
      price: 115000,
      city: "Hyderabad",
      bhk: "4 BHK",
      size: "2550 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 16,
      name: "Quality Independent House",
      price: 86000,
      city: "Chennai",
      bhk: "3 BHK",
      size: "2000 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 17,
      name: "Premium Independent House",
      price: 125000,
      city: "Mumbai",
      bhk: "4 BHK",
      size: "2700 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 18,
      name: "Comfortable Independent House",
      price: 60000,
      city: "Kolkata",
      bhk: "2 BHK",
      size: "1550 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 19,
      name: "Wonderful Independent House",
      price: 98000,
      city: "Pune",
      bhk: "3 BHK",
      size: "2150 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 20,
      name: "Magnificent Independent House",
      price: 130000,
      city: "Bangalore",
      bhk: "4 BHK",
      size: "2800 sq ft",
      image: "🏠",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Furnished",
    },
  ],
  villa: [
    {
      id: 1,
      name: "Luxury Villa",
      price: 150000,
      city: "Delhi",
      bhk: "4 BHK",
      size: "3000 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 2,
      name: "Modern Villa",
      price: 140000,
      city: "Bangalore",
      bhk: "3 BHK",
      size: "2800 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 3,
      name: "Grand Villa",
      price: 180000,
      city: "Mumbai",
      bhk: "5 BHK",
      size: "3500 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 4,
      name: "Elegant Villa",
      price: 120000,
      city: "Pune",
      bhk: "3 BHK",
      size: "2500 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 5,
      name: "Contemporary Villa",
      price: 160000,
      city: "Hyderabad",
      bhk: "4 BHK",
      size: "3100 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 6,
      name: "Premium Villa",
      price: 175000,
      city: "Delhi",
      bhk: "5 BHK",
      size: "3400 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 7,
      name: "Sophisticated Villa",
      price: 110000,
      city: "Kolkata",
      bhk: "3 BHK",
      size: "2400 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 8,
      name: "Exotic Villa",
      price: 155000,
      city: "Chennai",
      bhk: "4 BHK",
      size: "3050 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 9,
      name: "Stunning Villa",
      price: 145000,
      city: "Bangalore",
      bhk: "4 BHK",
      size: "2950 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 10,
      name: "Palatial Villa",
      price: 200000,
      city: "Mumbai",
      bhk: "6 BHK",
      size: "3800 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 11,
      name: "Refined Villa",
      price: 165000,
      city: "Ahmedabad",
      bhk: "4 BHK",
      size: "3150 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 12,
      name: "Charming Villa",
      price: 105000,
      city: "Pune",
      bhk: "3 BHK",
      size: "2350 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 13,
      name: "Beautiful Villa",
      price: 170000,
      city: "Bangalore",
      bhk: "4 BHK",
      size: "3200 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 14,
      name: "Spacious Villa",
      price: 135000,
      city: "Delhi",
      bhk: "3 BHK",
      size: "2750 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 15,
      name: "Lavish Villa",
      price: 195000,
      city: "Hyderabad",
      bhk: "5 BHK",
      size: "3650 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 16,
      name: "Serene Villa",
      price: 150000,
      city: "Chennai",
      bhk: "4 BHK",
      size: "3000 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 17,
      name: "Majestic Villa",
      price: 210000,
      city: "Mumbai",
      bhk: "6 BHK",
      size: "4000 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 18,
      name: "Quaint Villa",
      price: 115000,
      city: "Kolkata",
      bhk: "3 BHK",
      size: "2550 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/4246233/pexels-photo-4246233.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 19,
      name: "Opulent Villa",
      price: 185000,
      city: "Pune",
      bhk: "4 BHK",
      size: "3300 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 20,
      name: "Spectacular Villa",
      price: 220000,
      city: "Bangalore",
      bhk: "5 BHK",
      size: "4200 sq ft",
      image: "🏡",
      imageUrl: "https://images.pexels.com/photos/5768498/pexels-photo-5768498.jpeg",
      furnishing: "Furnished",
    },
  ],
  studio: [
    {
      id: 1,
      name: "Modern Studio",
      price: 20000,
      city: "Delhi",
      bhk: "Studio",
      size: "400 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 2,
      name: "Compact Studio",
      price: 18000,
      city: "Bangalore",
      bhk: "Studio",
      size: "380 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 3,
      name: "Luxury Studio",
      price: 28000,
      city: "Mumbai",
      bhk: "Studio",
      size: "500 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 4,
      name: "Affordable Studio",
      price: 15000,
      city: "Pune",
      bhk: "Studio",
      size: "350 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 5,
      name: "Spacious Studio",
      price: 25000,
      city: "Hyderabad",
      bhk: "Studio",
      size: "480 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 6,
      name: "Elegant Studio",
      price: 26000,
      city: "Delhi",
      bhk: "Studio",
      size: "490 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 7,
      name: "Budget Studio",
      price: 14000,
      city: "Kolkata",
      bhk: "Studio",
      size: "340 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 8,
      name: "Smart Studio",
      price: 22000,
      city: "Chennai",
      bhk: "Studio",
      size: "420 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 9,
      name: "Contemporary Studio",
      price: 24000,
      city: "Bangalore",
      bhk: "Studio",
      size: "460 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 10,
      name: "Premium Studio",
      price: 30000,
      city: "Mumbai",
      bhk: "Studio",
      size: "520 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 11,
      name: "Refined Studio",
      price: 23000,
      city: "Ahmedabad",
      bhk: "Studio",
      size: "440 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 12,
      name: "Cozy Studio",
      price: 16000,
      city: "Pune",
      bhk: "Studio",
      size: "360 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 13,
      name: "Sophisticated Studio",
      price: 27000,
      city: "Bangalore",
      bhk: "Studio",
      size: "510 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 14,
      name: "Vibrant Studio",
      price: 19000,
      city: "Delhi",
      bhk: "Studio",
      size: "390 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 15,
      name: "Exclusive Studio",
      price: 29000,
      city: "Hyderabad",
      bhk: "Studio",
      size: "530 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 16,
      name: "Urban Studio",
      price: 21000,
      city: "Chennai",
      bhk: "Studio",
      size: "410 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 17,
      name: "Upscale Studio",
      price: 31000,
      city: "Mumbai",
      bhk: "Studio",
      size: "540 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/7319297/pexels-photo-7319297.jpeg",
      furnishing: "Furnished",
    },
    {
      id: 18,
      name: "Value Studio",
      price: 17000,
      city: "Kolkata",
      bhk: "Studio",
      size: "370 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/6489127/pexels-photo-6489127.jpeg",
      furnishing: "Unfurnished",
    },
    {
      id: 19,
      name: "Professional Studio",
      price: 25000,
      city: "Pune",
      bhk: "Studio",
      size: "470 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/2972860/pexels-photo-2972860.jpeg",
      furnishing: "Semi-Furnished",
    },
    {
      id: 20,
      name: "Deluxe Studio",
      price: 32000,
      city: "Bangalore",
      bhk: "Studio",
      size: "550 sq ft",
      image: "🏢",
      imageUrl: "https://images.pexels.com/photos/8143666/pexels-photo-8143666.jpeg",
      furnishing: "Furnished",
    },
  ],
};

const typeNames: Record<string, string> = {
  apartment: "Apartments",
  independent: "Independent Houses",
  villa: "Villas",
  studio: "Studios",
};

export default function Houses() {
  const { type = "apartment" } = useParams<{ type?: string }>();
  const normalizedType = type?.toLowerCase() || "apartment";
  const houses = sampleHouses[normalizedType] || sampleHouses.apartment;
  const typeName = typeNames[normalizedType] || "Apartments";

  const [selectedProperty, setSelectedProperty] = useState<House | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleViewDetails = (house: House) => {
    setSelectedProperty(house);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedProperty(null), 300);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            {typeName}
          </h1>
          <p className="text-gray-600">
            Browse our collection of sample {typeName.toLowerCase()} across
            India
          </p>
        </div>

        {/* Houses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {houses.map((house) => (
            <div
              key={house.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105"
            >
              {/* Image */}
              <div className="relative bg-gradient-to-br from-purple-100 to-pink-100 h-40 overflow-hidden">
                {house.imageUrl ? (
                  <img
                    src={house.imageUrl}
                    alt={house.name}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full text-6xl">
                    {house.image}
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-3">
                  {house.name}
                </h3>

                {/* Price */}
                <div className="flex items-center gap-2 mb-4">
                  <DollarSign className="w-5 h-5 text-purple-600" />
                  <span className="text-2xl font-bold text-purple-600">
                    ₹{house.price.toLocaleString("en-IN")}
                  </span>
                </div>

                {/* Details */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="w-4 h-4 text-pink-600" />
                    <span className="text-sm">{house.city}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Home className="w-4 h-4 text-blue-600" />
                    <span className="text-sm">{house.bhk}</span>
                  </div>
                  <div className="text-sm text-gray-600">Size: {house.size}</div>
                  <div className="text-sm text-gray-600">
                    Furnishing: {house.furnishing}
                  </div>
                </div>

                {/* CTA Button */}
                <button
                  onClick={() => handleViewDetails(house)}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
                >
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Property Detail Modal */}
      <PropertyDetailModal
        property={selectedProperty}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
      />
    </div>
  );
}
