import { useState } from "react";
import { Loader2, AlertCircle } from "lucide-react";

interface PredictionResult {
  predictedRent: number;
  message: string;
}

export default function PredictRent() {
  const [formData, setFormData] = useState({
    houseType: "Apartment",
    city: "Mumbai",
    bhk: "2",
    size: "",
    furnishing: "Furnished",
    availability: "",
  });

  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const cities = [
    "Mumbai",
    "Delhi",
    "Bangalore",
    "Hyderabad",
    "Chennai",
    "Pune",
    "Kolkata",
    "Ahmedabad",
  ];

  const houseTypes = [
    "Apartment",
    "Independent House",
    "Villa",
    "Studio",
    "Penthouse",
  ];

  const bhkOptions = ["1", "2", "3", "4", "5", "6+"];

  const furnishingOptions = ["Furnished", "Semi-Furnished", "Unfurnished"];

  const availabilityOptions = [
    "Immediate",
    "15 days",
    "30 days",
    "45 days",
    "60 days",
  ];

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setError(null);
  };

  const validateForm = (): boolean => {
    if (!formData.size.trim()) {
      setError("Please enter the size of the property");
      return false;
    }

    const sizeNum = parseFloat(formData.size);
    if (isNaN(sizeNum) || sizeNum <= 0) {
      setError("Please enter a valid property size");
      return false;
    }

    if (!formData.availability) {
      setError("Please select availability");
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Failed to get prediction");
      }

      const data: PredictionResult = await response.json();
      setPrediction(data);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "An error occurred while predicting rent"
      );
      setPrediction(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-gray-800 mb-4 text-center">
          Predict Your Rent
        </h1>
        <p className="text-center text-gray-600 mb-12">
          Fill in the details to get an AI-powered rent prediction
        </p>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Error Message */}
            {error && (
              <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
                <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <p className="text-red-700">{error}</p>
              </div>
            )}

            {/* Form Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* House Type */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  House Type
                </label>
                <select
                  name="houseType"
                  value={formData.houseType}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  {houseTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>

              {/* City */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  City
                </label>
                <select
                  name="city"
                  value={formData.city}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  {cities.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
              </div>

              {/* BHK */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  BHK (Bedrooms)
                </label>
                <select
                  name="bhk"
                  value={formData.bhk}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  {bhkOptions.map((bhk) => (
                    <option key={bhk} value={bhk}>
                      {bhk} BHK
                    </option>
                  ))}
                </select>
              </div>

              {/* Size */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Size (sq. ft)
                </label>
                <input
                  type="number"
                  name="size"
                  value={formData.size}
                  onChange={handleInputChange}
                  placeholder="e.g., 1200"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>

              {/* Furnishing Status */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Furnishing Status
                </label>
                <select
                  name="furnishing"
                  value={formData.furnishing}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  {furnishingOptions.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>

              {/* Availability */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Availability
                </label>
                <select
                  name="availability"
                  value={formData.availability}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select Availability</option>
                  {availabilityOptions.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-bold text-lg hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading && <Loader2 className="w-5 h-5 animate-spin" />}
              {loading ? "Predicting..." : "Get Rent Prediction"}
            </button>
          </form>

          {/* Prediction Result */}
          {prediction && (
            <div className="mt-8 p-8 bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-2xl">
              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                Predicted Rent
              </h2>
              <div className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-blue-600 mb-4">
                ₹{prediction.predictedRent.toLocaleString("en-IN", {
                  minimumFractionDigits: 0,
                  maximumFractionDigits: 0,
                })}/month
              </div>
              <p className="text-gray-600">{prediction.message}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
