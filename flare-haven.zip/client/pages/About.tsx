import { useState } from "react";
import { CheckCircle, AlertCircle } from "lucide-react";

export default function About() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
    feedbackType: "feedback",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<{
    type: "success" | "error" | null;
    message: string;
  }>({
    type: null,
    message: "",
  });

  const feedbackTypes = [
    { value: "feedback", label: "General Feedback" },
    { value: "custom-prediction", label: "Custom Prediction Request" },
    { value: "listing", label: "House Listing Suggestion" },
  ];

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus({ type: null, message: "" });

    try {
      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Failed to submit feedback");
      }

      setSubmitStatus({
        type: "success",
        message:
          "Thank you! Your feedback has been submitted successfully. We'll review it and get back to you soon.",
      });

      setFormData({
        name: "",
        email: "",
        message: "",
        feedbackType: "feedback",
      });
    } catch (err) {
      setSubmitStatus({
        type: "error",
        message:
          err instanceof Error ? err.message : "Failed to submit feedback",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-16">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">About Us</h1>
          <div className="w-16 h-1 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full"></div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-16">
          {/* Description Section */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">
                Our Mission
              </h2>

              <div className="space-y-6 text-gray-600 leading-relaxed">
                <p>
                  <span className="font-bold text-gray-800">SmartRent</span> is
                  an innovative AI-powered web application designed to
                  revolutionize the way people estimate fair rental prices for
                  properties. Using advanced machine learning algorithms trained
                  on extensive real estate data, we help users make informed
                  decisions about rental valuations.
                </p>

                <p>
                  Our core mission is simple yet powerful:{" "}
                  <span className="font-semibold">
                    SmartRent uses AI to help users estimate fair rental prices
                    based on location and house features.
                  </span>{" "}
                  Whether you're a property owner looking to set competitive
                  rental prices, a tenant researching fair market rates, or a
                  real estate investor analyzing portfolios, SmartRent provides
                  accurate, data-driven predictions.
                </p>

                <p>
                  By leveraging cutting-edge data science and machine learning
                  techniques, we analyze multiple factors including:
                </p>

                <ul className="space-y-3 ml-4">
                  <li className="flex gap-3">
                    <span className="text-purple-600 font-bold">•</span>
                    <span>
                      <strong>Location & City:</strong> Neighborhood
                      demographics and market trends
                    </span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-purple-600 font-bold">•</span>
                    <span>
                      <strong>Property Features:</strong> BHK count, square
                      footage, and furnishing status
                    </span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-purple-600 font-bold">•</span>
                    <span>
                      <strong>Availability:</strong> Market timing and seasonal
                      variations
                    </span>
                  </li>
                  <li className="flex gap-3">
                    <span className="text-purple-600 font-bold">•</span>
                    <span>
                      <strong>Market Trends:</strong> Real-time rental market
                      data and analytics
                    </span>
                  </li>
                </ul>

                <p>
                  Our team is committed to providing accurate, transparent, and
                  user-friendly predictions that empower everyone in the real
                  estate market to make smarter decisions.
                </p>
              </div>
            </div>
          </div>

          {/* Stats Section */}
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl shadow-lg p-8 text-white">
              <div className="text-4xl font-bold mb-2">10K+</div>
              <p className="text-purple-100">Predictions Made</p>
            </div>

            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl shadow-lg p-8 text-white">
              <div className="text-4xl font-bold mb-2">50+</div>
              <p className="text-blue-100">Cities Covered</p>
            </div>

            <div className="bg-gradient-to-br from-pink-600 to-red-600 rounded-2xl shadow-lg p-8 text-white">
              <div className="text-4xl font-bold mb-2">95%</div>
              <p className="text-pink-100">Accuracy Rate</p>
            </div>
          </div>
        </div>

        {/* Feedback Form Section */}
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Share Your Feedback
          </h2>
          <p className="text-gray-600 mb-8">
            We'd love to hear from you! Share your feedback, request custom
            predictions, or suggest house listings.
          </p>

          {submitStatus.type && (
            <div
              className={`flex items-start gap-3 p-4 rounded-lg mb-6 ${
                submitStatus.type === "success"
                  ? "bg-green-50 border border-green-200"
                  : "bg-red-50 border border-red-200"
              }`}
            >
              {submitStatus.type === "success" ? (
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
              )}
              <p
                className={
                  submitStatus.type === "success"
                    ? "text-green-700"
                    : "text-red-700"
                }
              >
                {submitStatus.message}
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Name */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Your name"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="your.email@example.com"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Feedback Type */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                What is your message about?
              </label>
              <select
                name="feedbackType"
                value={formData.feedbackType}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                {feedbackTypes.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Message */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Message
              </label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleInputChange}
                placeholder="Tell us your thoughts..."
                rows={5}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
              ></textarea>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-bold text-lg hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? "Submitting..." : "Send Feedback"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
