import { useState } from "react";
import { Link } from "react-router-dom";
import { ChevronDown } from "lucide-react";

const Navbar = () => {
  const [isHouseTypesOpen, setIsHouseTypesOpen] = useState(false);

  const houseTypes = [
    { name: "Apartment", path: "/houses/apartment" },
    { name: "Independent House", path: "/houses/independent" },
    { name: "Villa", path: "/houses/villa" },
    { name: "Studio", path: "/houses/studio" },
  ];

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Left side - Logo */}
          <Link to="/" className="flex items-center">
            <span
              className="text-3xl font-bold text-purple-600"
              style={{ fontFamily: "Dancing Script" }}
            >
              SmartRent
            </span>
          </Link>

          {/* Right side - Navigation */}
          <div className="flex items-center space-x-8">
            <Link
              to="/"
              className="text-gray-700 hover:text-purple-600 transition duration-200 font-medium"
            >
              Home
            </Link>

            <Link
              to="/about"
              className="text-gray-700 hover:text-purple-600 transition duration-200 font-medium"
            >
              About Us
            </Link>

            <Link
              to="/predict"
              className="text-gray-700 hover:text-purple-600 transition duration-200 font-medium"
            >
              Predict Rent
            </Link>

            {/* House Types Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setIsHouseTypesOpen(true)}
              onMouseLeave={() => setIsHouseTypesOpen(false)}
            >
              <button className="flex items-center gap-2 text-gray-700 hover:text-purple-600 transition duration-200 font-medium">
                House Types
                <ChevronDown
                  className={`w-4 h-4 transition-transform ${
                    isHouseTypesOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {isHouseTypesOpen && (
                <div className="absolute left-0 mt-0 w-48 bg-white border border-gray-200 rounded-lg shadow-lg py-2">
                  {houseTypes.map((type) => (
                    <Link
                      key={type.name}
                      to={type.path}
                      className="block px-4 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-600 transition duration-200"
                      onClick={() => setIsHouseTypesOpen(false)}
                    >
                      {type.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link
              to="/contact"
              className="text-gray-700 hover:text-purple-600 transition duration-200 font-medium"
            >
              Contact
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
