import { X, MapPin, Home, DollarSign, Maximize2, Sofa } from "lucide-react";

interface Property {
  id: number;
  name: string;
  price: number;
  city: string;
  bhk: string;
  size: string;
  imageUrl?: string;
  furnishing: string;
}

interface PropertyDetailModalProps {
  property: Property | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function PropertyDetailModal({
  property,
  isOpen,
  onClose,
}: PropertyDetailModalProps) {
  if (!isOpen || !property) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 flex justify-between items-center p-6 border-b border-gray-200 bg-white">
          <h2 className="text-2xl font-bold text-gray-800">Property Details</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Image */}
          {property.imageUrl && (
            <div className="mb-6 rounded-xl overflow-hidden">
              <img
                src={property.imageUrl}
                alt={property.name}
                className="w-full h-80 object-cover"
              />
            </div>
          )}

          {/* Title and Price */}
          <div className="mb-6">
            <h3 className="text-3xl font-bold text-gray-800 mb-3">
              {property.name}
            </h3>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
                ₹{property.price.toLocaleString("en-IN")}
              </span>
              <span className="text-gray-600">/month</span>
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 md:grid-cols-2 gap-6 mb-8">
            {/* Location */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl">
              <div className="flex items-center gap-3 mb-2">
                <MapPin className="w-6 h-6 text-blue-600" />
                <span className="text-sm font-semibold text-gray-600">
                  Location
                </span>
              </div>
              <p className="text-xl font-bold text-gray-800">{property.city}</p>
            </div>

            {/* BHK */}
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl">
              <div className="flex items-center gap-3 mb-2">
                <Home className="w-6 h-6 text-purple-600" />
                <span className="text-sm font-semibold text-gray-600">
                  Property Type
                </span>
              </div>
              <p className="text-xl font-bold text-gray-800">{property.bhk}</p>
            </div>

            {/* Size */}
            <div className="bg-gradient-to-br from-pink-50 to-pink-100 p-6 rounded-xl">
              <div className="flex items-center gap-3 mb-2">
                <Maximize2 className="w-6 h-6 text-pink-600" />
                <span className="text-sm font-semibold text-gray-600">Size</span>
              </div>
              <p className="text-xl font-bold text-gray-800">{property.size}</p>
            </div>

            {/* Furnishing */}
            <div className="bg-gradient-to-br from-amber-50 to-amber-100 p-6 rounded-xl">
              <div className="flex items-center gap-3 mb-2">
                <Sofa className="w-6 h-6 text-amber-600" />
                <span className="text-sm font-semibold text-gray-600">
                  Furnishing
                </span>
              </div>
              <p className="text-xl font-bold text-gray-800">
                {property.furnishing}
              </p>
            </div>
          </div>

          {/* Description */}
          <div className="bg-gray-50 p-6 rounded-xl mb-6">
            <h4 className="text-lg font-bold text-gray-800 mb-3">
              Property Information
            </h4>
            <p className="text-gray-600 leading-relaxed">
              This beautiful {property.furnishing.toLowerCase()} {property.bhk} property is
              located in {property.city}. With a spacious {property.size} area, it offers
              excellent value for money. Perfect for those looking for a comfortable and
              well-appointed living space with modern amenities.
            </p>
          </div>

          {/* Features List */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            {[
              "Spacious Rooms",
              "Natural Light",
              "Modern Kitchen",
              "Secure Building",
              "Good Ventilation",
              "Prime Location",
            ].map((feature) => (
              <div key={feature} className="flex items-center gap-2">
                <div className="w-2 h-2 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full"></div>
                <span className="text-gray-700">{feature}</span>
              </div>
            ))}
          </div>

          {/* Contact Section */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-xl mb-6">
            <h4 className="text-lg font-bold text-gray-800 mb-4">
              Interested in this property?
            </h4>
            <p className="text-gray-600 mb-4">
              Get in touch with us to schedule a viewing or learn more about this
              property.
            </p>
            <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-bold hover:shadow-lg transition-all duration-300">
              Contact Agent
            </button>
          </div>

          {/* Close Button */}
          <button
            onClick={onClose}
            className="w-full border-2 border-gray-300 text-gray-700 py-3 rounded-lg font-bold hover:bg-gray-50 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
