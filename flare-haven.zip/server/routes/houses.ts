import { RequestHandler } from "express";

interface House {
  id: number;
  name: string;
  price: number;
  city: string;
  bhk: string;
  size: string;
  furnishing: string;
  type: string;
}

const sampleHouses: Record<string, House[]> = {
  apartment: [
    {
      id: 1,
      name: "Modern Apartment in Downtown",
      price: 45000,
      city: "Mumbai",
      bhk: "2 BHK",
      size: "1200 sq ft",
      furnishing: "Furnished",
      type: "apartment",
    },
    {
      id: 2,
      name: "Cozy Apartment with City View",
      price: 38000,
      city: "Delhi",
      bhk: "2 BHK",
      size: "1000 sq ft",
      furnishing: "Semi-Furnished",
      type: "apartment",
    },
    {
      id: 3,
      name: "Luxury Apartment",
      price: 65000,
      city: "Bangalore",
      bhk: "3 BHK",
      size: "1500 sq ft",
      furnishing: "Furnished",
      type: "apartment",
    },
    {
      id: 4,
      name: "Budget-Friendly Apartment",
      price: 25000,
      city: "Pune",
      bhk: "1 BHK",
      size: "600 sq ft",
      furnishing: "Unfurnished",
      type: "apartment",
    },
    {
      id: 5,
      name: "Spacious Family Apartment",
      price: 55000,
      city: "Hyderabad",
      bhk: "3 BHK",
      size: "1400 sq ft",
      furnishing: "Semi-Furnished",
      type: "apartment",
    },
  ],
  independent: [
    {
      id: 1,
      name: "Modern Independent House",
      price: 85000,
      city: "Delhi",
      bhk: "3 BHK",
      size: "2000 sq ft",
      furnishing: "Furnished",
      type: "independent",
    },
    {
      id: 2,
      name: "Spacious Independent House",
      price: 75000,
      city: "Bangalore",
      bhk: "2 BHK",
      size: "1800 sq ft",
      furnishing: "Semi-Furnished",
      type: "independent",
    },
    {
      id: 3,
      name: "Luxury Independent House",
      price: 120000,
      city: "Mumbai",
      bhk: "4 BHK",
      size: "2500 sq ft",
      furnishing: "Furnished",
      type: "independent",
    },
    {
      id: 4,
      name: "Family Independent House",
      price: 65000,
      city: "Pune",
      bhk: "2 BHK",
      size: "1600 sq ft",
      furnishing: "Unfurnished",
      type: "independent",
    },
    {
      id: 5,
      name: "Contemporary Independent House",
      price: 95000,
      city: "Hyderabad",
      bhk: "3 BHK",
      size: "2100 sq ft",
      furnishing: "Semi-Furnished",
      type: "independent",
    },
  ],
  villa: [
    {
      id: 1,
      name: "Luxury Villa",
      price: 150000,
      city: "Delhi",
      bhk: "4 BHK",
      size: "3000 sq ft",
      furnishing: "Furnished",
      type: "villa",
    },
    {
      id: 2,
      name: "Modern Villa",
      price: 140000,
      city: "Bangalore",
      bhk: "3 BHK",
      size: "2800 sq ft",
      furnishing: "Semi-Furnished",
      type: "villa",
    },
    {
      id: 3,
      name: "Grand Villa",
      price: 180000,
      city: "Mumbai",
      bhk: "5 BHK",
      size: "3500 sq ft",
      furnishing: "Furnished",
      type: "villa",
    },
    {
      id: 4,
      name: "Elegant Villa",
      price: 120000,
      city: "Pune",
      bhk: "3 BHK",
      size: "2500 sq ft",
      furnishing: "Unfurnished",
      type: "villa",
    },
    {
      id: 5,
      name: "Contemporary Villa",
      price: 160000,
      city: "Hyderabad",
      bhk: "4 BHK",
      size: "3100 sq ft",
      furnishing: "Semi-Furnished",
      type: "villa",
    },
  ],
  studio: [
    {
      id: 1,
      name: "Modern Studio",
      price: 20000,
      city: "Delhi",
      bhk: "Studio",
      size: "400 sq ft",
      furnishing: "Furnished",
      type: "studio",
    },
    {
      id: 2,
      name: "Compact Studio",
      price: 18000,
      city: "Bangalore",
      bhk: "Studio",
      size: "380 sq ft",
      furnishing: "Semi-Furnished",
      type: "studio",
    },
    {
      id: 3,
      name: "Luxury Studio",
      price: 28000,
      city: "Mumbai",
      bhk: "Studio",
      size: "500 sq ft",
      furnishing: "Furnished",
      type: "studio",
    },
    {
      id: 4,
      name: "Affordable Studio",
      price: 15000,
      city: "Pune",
      bhk: "Studio",
      size: "350 sq ft",
      furnishing: "Unfurnished",
      type: "studio",
    },
    {
      id: 5,
      name: "Spacious Studio",
      price: 25000,
      city: "Hyderabad",
      bhk: "Studio",
      size: "480 sq ft",
      furnishing: "Semi-Furnished",
      type: "studio",
    },
  ],
};

export const getHouses: RequestHandler = (req, res) => {
  try {
    const { type = "apartment" } = req.query;
    const normalizedType = (type as string).toLowerCase();
    const houses = sampleHouses[normalizedType] || sampleHouses.apartment;

    res.json({
      type: normalizedType,
      count: houses.length,
      houses,
    });
  } catch (error) {
    console.error("Error in houses endpoint:", error);
    res.status(500).json({
      error: "Failed to fetch houses",
    });
  }
};

export const getHousesByType: RequestHandler = (req, res) => {
  try {
    const { type } = req.params;
    const normalizedType = type.toLowerCase();
    const houses = sampleHouses[normalizedType] || sampleHouses.apartment;

    res.json({
      type: normalizedType,
      count: houses.length,
      houses,
    });
  } catch (error) {
    console.error("Error in houses by type endpoint:", error);
    res.status(500).json({
      error: "Failed to fetch houses",
    });
  }
};
