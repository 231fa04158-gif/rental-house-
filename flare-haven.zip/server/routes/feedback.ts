import { RequestHandler } from "express";

interface FeedbackRequest {
  name: string;
  email: string;
  message: string;
  feedbackType: string;
}

// In-memory storage for feedback (in production, this would be MongoDB)
const feedbackStorage: FeedbackRequest[] = [];

export const handleFeedback: RequestHandler = (req, res) => {
  try {
    const data = req.body as FeedbackRequest;

    // Validation
    if (!data.name || !data.email || !data.message || !data.feedbackType) {
      return res.status(400).json({
        error: "Missing required fields",
      });
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      return res.status(400).json({
        error: "Invalid email address",
      });
    }

    // Store feedback (in production, save to MongoDB)
    const feedback: FeedbackRequest & { timestamp: string } = {
      ...data,
      timestamp: new Date().toISOString(),
    };

    feedbackStorage.push(data);

    res.json({
      success: true,
      message: "Thank you for your feedback!",
      feedback,
    });
  } catch (error) {
    console.error("Error in feedback endpoint:", error);
    res.status(500).json({
      error: "Failed to process feedback",
    });
  }
};

export const getFeedback: RequestHandler = (req, res) => {
  try {
    res.json({
      count: feedbackStorage.length,
      feedback: feedbackStorage,
    });
  } catch (error) {
    console.error("Error fetching feedback:", error);
    res.status(500).json({
      error: "Failed to fetch feedback",
    });
  }
};
