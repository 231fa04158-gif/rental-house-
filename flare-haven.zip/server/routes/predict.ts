import { RequestHandler } from "express";

interface PredictRequest {
  houseType: string;
  city: string;
  bhk: string;
  size: string;
  furnishing: string;
  availability: string;
}

interface PredictResponse {
  predictedRent: number;
  message: string;
}

// Simple ML model simulation - in production, this would call a Python backend
// For now, we use a heuristic-based calculation based on multiple factors
function predictRent(data: PredictRequest): number {
  const cityMultiplier: Record<string, number> = {
    Mumbai: 1.5,
    Delhi: 1.4,
    Bangalore: 1.35,
    Hyderabad: 1.2,
    Chennai: 1.1,
    Pune: 1.25,
    Kolkata: 0.9,
    Ahmedabad: 1.0,
  };

  const houseTypeMultiplier: Record<string, number> = {
    Apartment: 1.0,
    "Independent House": 1.3,
    Villa: 1.8,
    Studio: 0.7,
    Penthouse: 2.0,
  };

  const furnishingMultiplier: Record<string, number> = {
    Furnished: 1.3,
    "Semi-Furnished": 1.15,
    Unfurnished: 1.0,
  };

  const bhkMultiplier: Record<string, number> = {
    "1": 1.0,
    "2": 1.5,
    "3": 2.1,
    "4": 2.8,
    "5": 3.5,
    "6+": 4.0,
  };

  const availabilityMultiplier: Record<string, number> = {
    Immediate: 1.2,
    "15 days": 1.15,
    "30 days": 1.0,
    "45 days": 0.95,
    "60 days": 0.9,
  };

  // Base rent calculation
  const baseRent = 20000;
  const size = parseFloat(data.size) || 1000;
  const sizeMultiplier = size / 1000;

  // Calculate all multipliers
  const city = cityMultiplier[data.city] || 1.0;
  const houseType = houseTypeMultiplier[data.houseType] || 1.0;
  const furnishing = furnishingMultiplier[data.furnishing] || 1.0;
  const bhk = bhkMultiplier[data.bhk] || 1.5;
  const availability = availabilityMultiplier[data.availability] || 1.0;

  // Calculate predicted rent
  const predictedRent = Math.round(
    baseRent * sizeMultiplier * city * houseType * furnishing * bhk * availability
  );

  return predictedRent;
}

export const handlePredict: RequestHandler = (req, res) => {
  try {
    const data = req.body as PredictRequest;

    // Validation
    if (!data.houseType || !data.city || !data.bhk || !data.size || !data.furnishing || !data.availability) {
      return res.status(400).json({
        error: "Missing required fields",
      });
    }

    const sizeNum = parseFloat(data.size);
    if (isNaN(sizeNum) || sizeNum <= 0) {
      return res.status(400).json({
        error: "Invalid property size",
      });
    }

    // Get prediction
    const predictedRent = predictRent(data);

    const response: PredictResponse = {
      predictedRent,
      message: `Based on your ${data.bhk} ${data.houseType.toLowerCase()} in ${data.city}, the estimated fair rental price is ₹${predictedRent.toLocaleString("en-IN")} per month.`,
    };

    res.json(response);
  } catch (error) {
    console.error("Error in predict endpoint:", error);
    res.status(500).json({
      error: "Failed to process prediction",
    });
  }
};
